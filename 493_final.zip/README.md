sched-sim
=========

Simulation of task scheduler for OpenOrbiter

1. Clone the repository

2. Compile with the following
```
g++ -o gen testgen.cpp mt19937ar.c
g++ -o sim metric.c
```
3. Use the compiled programs to generate and test sets of test data!
